export const daysOfWeek = [
    { name: 'Dom', value: 'domingo' },
    { name: 'Seg', value: 'segunda' },
    { name: 'Ter', value: 'terca' },
    { name: 'Qua', value: 'quarta' },
    { name: 'Qui', value: 'quinta' },
    { name: 'Sex', value: 'sexta' },
    { name: 'Sáb', value: 'sabado' },
  ];
  